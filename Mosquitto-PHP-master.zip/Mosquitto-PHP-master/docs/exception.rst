====================
Mosquitto\\Exception
====================

.. php:namespace:: Mosquitto

.. php:class:: Exception

This is an exception that may be thrown by many of the operations in the ``Client`` object. It does not add any features to the standard PHP ``Exception`` class.

