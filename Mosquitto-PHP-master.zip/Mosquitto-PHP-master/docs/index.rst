.. Mosquitto-PHP documentation master file, created by
   sphinx-quickstart on Mon Sep  5 20:57:18 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

=============
Mosquitto-PHP
=============

This is an extension to allow using the `Eclipse Mosquitto™ MQTT client library <http://mosquitto.org>`_ with PHP.

See the ``examples`` directory for usage.

Contents
========

.. toctree::
   :maxdepth: 2
   
   overview
   client
   message
   exception



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

