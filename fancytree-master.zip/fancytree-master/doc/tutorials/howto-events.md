#Howto write events

TODO
