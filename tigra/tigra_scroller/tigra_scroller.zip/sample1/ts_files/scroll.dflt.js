DEFAULT = {
	'clas' : {
		'bck':'Back',
		'aup':'ArrowUp',
		'adn':'ArrowDn',
		'itm':'ItemBody'
	},
	'size' : [150, 100],
	'up' : 'aup.gif',
	'dn' : 'adn.gif'
}